<%@ Page Title="" Language="C#" MasterPageFile="~/manager/Manage.master" %>

<script runat="server">
    protected string currentVersion = "1.0.0";
    protected string latestVersion = "";
    protected string updateLog = "";
    protected bool hasUpdate = false;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        // 每次加载都读取当前版本号，确保显示最新值
        LoadCurrentVersion();
    }
    
    private void LoadCurrentVersion()
    {
        try
        {
            // 从 changelog.xml 读取当前版本号（与 index.aspx 保持一致）
            string xmlPath = Server.MapPath("~/changelog.xml");
            if (System.IO.File.Exists(xmlPath))
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.Load(xmlPath);
                
                // 获取第一个 version 节点（最新版本）
                System.Xml.XmlNode firstVersion = doc.SelectSingleNode("//changelog/version");
                if (firstVersion != null && firstVersion.Attributes["ver"] != null)
                {
                    string ver = firstVersion.Attributes["ver"].Value;
                    if (!string.IsNullOrEmpty(ver))
                    {
                        currentVersion = ver;
                        return; // 成功读取，直接返回
                    }
                }
            }
            
            // 如果 changelog.xml 不存在或没有版本信息，尝试从 version.txt 读取
            string versionFile = Server.MapPath("~/version.txt");
            if (System.IO.File.Exists(versionFile))
            {
                string ver = System.IO.File.ReadAllText(versionFile).Trim();
                if (!string.IsNullOrEmpty(ver))
                {
                    currentVersion = ver;
                    return;
                }
            }
            
            // 如果都读取失败，保持默认值 1.0.0
        }
        catch (Exception ex)
        {
            // 调试：可以记录错误
            // lblMessage.Text = "读取版本号失败：" + ex.Message;
        }
    }
    
    protected void BtnCheckUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            lblMessage.Text = "正在检查更新...";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(59, 130, 246);
            
            // 从远程服务器检查更新
            string updateUrl = txtUpdateUrl.Text.Trim();
            
            // 如果用户输入的是旧的不可用地址，清空它
            if (updateUrl == "http://update.lequw.net/learnsite/version.json" || 
                updateUrl == "https://update.lequw.net/learnsite/version.json")
            {
                updateUrl = "";
                txtUpdateUrl.Text = "";
            }
            
            if (string.IsNullOrEmpty(updateUrl))
            {
                // 使用本地的 version.json 作为默认（如果存在）
                string localVersionFile = Server.MapPath("~/version.json");
                if (System.IO.File.Exists(localVersionFile))
                {
                    try
                    {
                        string jsonData = System.IO.File.ReadAllText(localVersionFile, System.Text.Encoding.UTF8);
                        ProcessVersionData(jsonData);
                        return;
                    }
                    catch { }
                }
                
                // 如果本地文件不存在，提示用户
                lblMessage.Text = "请配置更新服务器地址，或将 version.json 文件放置在网站根目录。<br/><br/>" +
                                 "您可以：<br/>" +
                                 "1. 搭建自己的更新服务器（推荐）<br/>" +
                                 "2. 使用GitHub托管更新文件<br/>" +
                                 "3. 将 version.json 放在网站根目录进行本地更新<br/><br/>" +
                                 "详细说明请查看：manager/系统更新故障排查指南.md";
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(245, 158, 11);
                divUpdateInfo.Visible = false;
                btnDownloadUpdate.Visible = false;
                return;
            }
            
            // 启用 TLS 1.2（修复 HTTPS 连接问题）
            try
            {
                // SecurityProtocolType.Tls12 = 3072
                System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;
            }
            catch
            {
                // 如果不支持 TLS 1.2，尝试使用所有可用协议
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = 
                        System.Net.SecurityProtocolType.Ssl3 | 
                        System.Net.SecurityProtocolType.Tls | 
                        (System.Net.SecurityProtocolType)768 | // Tls11
                        (System.Net.SecurityProtocolType)3072; // Tls12
                }
                catch
                {
                    System.Net.ServicePointManager.SecurityProtocol = 
                        System.Net.SecurityProtocolType.Ssl3 | 
                        System.Net.SecurityProtocolType.Tls;
                }
            }
            
            // 设置超时时间
            System.Net.WebClient client = new System.Net.WebClient();
            client.Encoding = System.Text.Encoding.UTF8;
            
            // 添加User-Agent避免被服务器拒绝
            client.Headers.Add("User-Agent", "LearnSite-UpdateChecker/1.0");
            
            string jsonData2 = "";
            try
            {
                // 设置超时时间（30秒）
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(updateUrl);
                request.Timeout = 30000;
                request.UserAgent = "LearnSite-UpdateChecker/1.0";
                request.Method = "GET";
                
                using (System.Net.HttpWebResponse response = (System.Net.HttpWebResponse)request.GetResponse())
                {
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8))
                    {
                        jsonData2 = reader.ReadToEnd();
                    }
                }
            }
            catch (System.Net.WebException webEx)
            {
                string errorMsg = "连接更新服务器失败：<br/><br/>";
                
                // 详细的错误信息
                if (webEx.Status == System.Net.WebExceptionStatus.ProtocolError && webEx.Response != null)
                {
                    System.Net.HttpWebResponse response = (System.Net.HttpWebResponse)webEx.Response;
                    errorMsg += "<strong>HTTP错误：</strong>" + ((int)response.StatusCode) + " - " + response.StatusDescription + "<br/><br/>";
                    
                    // 如果是404，提供更详细的说明
                    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        errorMsg += "<strong>可能的原因：</strong><br/>" +
                                   "• 更新服务器地址不正确<br/>" +
                                   "• 版本文件不存在<br/>" +
                                   "• 服务器配置问题<br/><br/>";
                    }
                }
                else
                {
                    // 其他网络错误
                    errorMsg += "<strong>错误类型：</strong>" + webEx.Status.ToString() + "<br/>";
                    errorMsg += "<strong>错误信息：</strong>" + webEx.Message + "<br/>";
                    
                    if (webEx.InnerException != null)
                    {
                        errorMsg += "<strong>详细信息：</strong>" + webEx.InnerException.Message + "<br/>";
                    }
                    
                    errorMsg += "<br/><strong>常见原因：</strong><br/>";
                    
                    if (webEx.Status == System.Net.WebExceptionStatus.Timeout)
                    {
                        errorMsg += "• 连接超时，请检查网络连接<br/>";
                        errorMsg += "• 服务器响应过慢<br/>";
                    }
                    else if (webEx.Status == System.Net.WebExceptionStatus.NameResolutionFailure)
                    {
                        errorMsg += "• 无法解析域名，请检查DNS设置<br/>";
                        errorMsg += "• 服务器地址可能不正确<br/>";
                    }
                    else if (webEx.Status == System.Net.WebExceptionStatus.ConnectFailure)
                    {
                        errorMsg += "• 无法连接到服务器<br/>";
                        errorMsg += "• 服务器可能未运行或防火墙阻止<br/>";
                    }
                    else if (webEx.Status == System.Net.WebExceptionStatus.TrustFailure || 
                             webEx.Status == System.Net.WebExceptionStatus.SecureChannelFailure)
                    {
                        errorMsg += "• SSL/TLS证书验证失败<br/>";
                        errorMsg += "• 服务器证书可能过期或不受信任<br/>";
                        errorMsg += "• 尝试使用HTTP而非HTTPS<br/>";
                    }
                    else
                    {
                        errorMsg += "• 网络连接问题<br/>";
                        errorMsg += "• 防火墙或代理服务器阻止<br/>";
                        errorMsg += "• 服务器暂时不可用<br/>";
                    }
                }
                
                errorMsg += "<br/><strong>解决方案：</strong><br/>" +
                           "1. <strong>使用本地更新</strong>（推荐）：清空地址框，将 version.json 放在网站根目录<br/>" +
                           "2. <strong>检查网络</strong>：确认服务器可以访问外网<br/>" +
                           "3. <strong>检查地址</strong>：确认更新服务器地址正确且可访问<br/>" +
                           "4. <strong>手动更新</strong>：下载更新包手动安装<br/><br/>" +
                           "详细说明：manager/系统更新快速修复.txt";
                
                lblMessage.Text = errorMsg;
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                divUpdateInfo.Visible = false;
                btnDownloadUpdate.Visible = false;
                return;
            }
            catch (System.UriFormatException uriEx)
            {
                lblMessage.Text = "更新服务器地址格式错误：<br/><br/>" + 
                                 uriEx.Message + "<br/><br/>" +
                                 "<strong>正确格式示例：</strong><br/>" +
                                 "• http://192.168.1.100/updates/version.json<br/>" +
                                 "• https://example.com/learnsite/version.json<br/><br/>" +
                                 "或清空地址框使用本地 version.json 文件";
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                divUpdateInfo.Visible = false;
                btnDownloadUpdate.Visible = false;
                return;
            }
            
            ProcessVersionData(jsonData2);
        }
        catch (Exception ex)
        {
            string errorMsg = "检查更新失败：" + ex.Message;
            if (ex.InnerException != null)
            {
                errorMsg += "<br/>详细信息：" + ex.InnerException.Message;
            }
            errorMsg += "<br/><br/>请检查：<br/>" +
                       "1. 网络连接是否正常<br/>" +
                       "2. 更新服务器地址是否正确<br/>" +
                       "3. 服务器防火墙是否允许访问外部网络<br/><br/>" +
                       "或使用手动更新方式，详见：manager/系统更新快速修复.txt";
            
            lblMessage.Text = errorMsg;
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
            divUpdateInfo.Visible = false;
            btnDownloadUpdate.Visible = false;
        }
    }
    
    private void ProcessVersionData(string jsonData)
    {
        if (string.IsNullOrEmpty(jsonData))
        {
            lblMessage.Text = "更新服务器返回空数据";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
            divUpdateInfo.Visible = false;
            btnDownloadUpdate.Visible = false;
            return;
        }
        
        // 解析JSON（简单解析）
        latestVersion = ExtractJsonValue(jsonData, "version");
        updateLog = ExtractJsonValue(jsonData, "changelog");
        string downloadUrl = ExtractJsonValue(jsonData, "downloadUrl");
        
        if (string.IsNullOrEmpty(latestVersion))
        {
            lblMessage.Text = "无法解析版本信息，请检查更新服务器返回的数据格式<br/><br/>" +
                             "version.json 格式示例请查看：version.json.example";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
            divUpdateInfo.Visible = false;
            btnDownloadUpdate.Visible = false;
            return;
        }
        
        ViewState["LatestVersion"] = latestVersion;
        ViewState["UpdateLog"] = updateLog;
        ViewState["DownloadUrl"] = downloadUrl;
        
        if (CompareVersion(latestVersion, currentVersion) > 0)
        {
            hasUpdate = true;
            lblMessage.Text = "发现新版本 " + latestVersion + "，可以更新！";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(34, 197, 94);
            divUpdateInfo.Visible = true;
            litLatestVersion.Text = latestVersion;
            litUpdateLog.Text = string.IsNullOrEmpty(updateLog) ? "暂无更新说明" : updateLog.Replace("\n", "<br/>");
            
            if (!string.IsNullOrEmpty(downloadUrl))
            {
                lnkManualDownload.NavigateUrl = downloadUrl;
                string fileName = downloadUrl.Contains("/") ? downloadUrl.Substring(downloadUrl.LastIndexOf('/') + 1) : "update.zip";
                lnkManualDownload.Text = "手动下载更新包 (" + fileName + ")";
                lnkManualDownload.Visible = true;
                btnDownloadUpdate.Visible = true;
            }
            else
            {
                lnkManualDownload.Visible = false;
                btnDownloadUpdate.Visible = false;
                lblMessage.Text += "<br/><span style='color:#f59e0b;'>注意：未提供下载地址，请手动更新</span>";
            }
        }
        else
        {
            lblMessage.Text = "当前已是最新版本！";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            divUpdateInfo.Visible = false;
            btnDownloadUpdate.Visible = false;
        }
    }
    
    protected void BtnDownloadUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string downloadUrl = ViewState["DownloadUrl"] as string;
            
            // 严格检查下载地址
            if (string.IsNullOrEmpty(downloadUrl))
            {
                lblMessage.Text = "下载地址无效：未配置下载地址<br/><br/>" +
                                 "<strong>原因：</strong><br/>" +
                                 "version.json 文件中的 downloadUrl 字段为空<br/><br/>" +
                                 "<strong>解决方案：</strong><br/>" +
                                 "1. <strong>手动更新</strong>（推荐）：从官方渠道下载更新包，手动解压安装<br/>" +
                                 "2. <strong>配置下载地址</strong>：在 version.json 中添加有效的 downloadUrl<br/>" +
                                 "3. <strong>联系管理员</strong>：获取更新包下载地址<br/><br/>" +
                                 "详细说明：manager/系统更新快速修复.txt";
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                divUpdateInfo.Visible = false;
                btnDownloadUpdate.Visible = false;
                return;
            }
            
            // 验证URL格式
            try
            {
                System.Uri uri = new System.Uri(downloadUrl);
                if (uri.Scheme != "http" && uri.Scheme != "https")
                {
                    lblMessage.Text = "下载地址格式错误：只支持 HTTP 或 HTTPS 协议<br/><br/>" +
                                     "当前地址：" + downloadUrl + "<br/><br/>" +
                                     "请使用手动更新方式。";
                    lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                    return;
                }
            }
            catch (System.UriFormatException)
            {
                lblMessage.Text = "下载地址格式错误：<br/><br/>" +
                                 "当前地址：" + downloadUrl + "<br/><br/>" +
                                 "请检查 version.json 中的 downloadUrl 格式是否正确。";
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                return;
            }
            
            lblMessage.Text = "正在下载更新包...";
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(59, 130, 246);
            
            // 启用 TLS 1.2（修复 HTTPS 下载问题）
            try
            {
                System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;
            }
            catch
            {
                try
                {
                    System.Net.ServicePointManager.SecurityProtocol = 
                        System.Net.SecurityProtocolType.Ssl3 | 
                        System.Net.SecurityProtocolType.Tls | 
                        (System.Net.SecurityProtocolType)768 | // Tls11
                        (System.Net.SecurityProtocolType)3072; // Tls12
                }
                catch
                {
                    System.Net.ServicePointManager.SecurityProtocol = 
                        System.Net.SecurityProtocolType.Ssl3 | 
                        System.Net.SecurityProtocolType.Tls;
                }
            }
            
            // 下载更新包
            string tempPath = Server.MapPath("~/App_Data/Temp");
            if (!System.IO.Directory.Exists(tempPath))
                System.IO.Directory.CreateDirectory(tempPath);
            
            string zipFile = System.IO.Path.Combine(tempPath, "update.zip");
            
            try
            {
                // 使用HttpWebRequest下载，更好的错误处理
                System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(downloadUrl);
                request.Timeout = 300000; // 5分钟超时
                request.UserAgent = "LearnSite-UpdateChecker/1.0";
                request.Method = "GET";
                
                using (System.Net.HttpWebResponse response = (System.Net.HttpWebResponse)request.GetResponse())
                {
                    using (System.IO.Stream responseStream = response.GetResponseStream())
                    {
                        using (System.IO.FileStream fileStream = new System.IO.FileStream(zipFile, System.IO.FileMode.Create))
                        {
                            byte[] buffer = new byte[8192];
                            int bytesRead;
                            while ((bytesRead = responseStream.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                fileStream.Write(buffer, 0, bytesRead);
                            }
                        }
                    }
                }
            }
            catch (System.Net.WebException webEx)
            {
                string errorMsg = "下载更新包失败：<br/><br/>";
                
                if (webEx.Status == System.Net.WebExceptionStatus.ProtocolError && webEx.Response != null)
                {
                    System.Net.HttpWebResponse response = (System.Net.HttpWebResponse)webEx.Response;
                    errorMsg += "HTTP " + ((int)response.StatusCode) + " - " + response.StatusDescription;
                }
                else
                {
                    errorMsg += webEx.Status.ToString() + ": " + webEx.Message;
                    if (webEx.InnerException != null)
                    {
                        errorMsg += "<br/>详细信息：" + webEx.InnerException.Message;
                    }
                }
                
                errorMsg += "<br/><br/>请尝试手动下载更新包并安装。";
                
                lblMessage.Text = errorMsg;
                lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
                return;
            }
            
            lblMessage.Text = "下载完成！正在解压更新包...";
            
            // 解压更新包（使用Shell.Application COM对象，兼容.NET 2.0）
            string extractPath = System.IO.Path.Combine(tempPath, "update");
            if (System.IO.Directory.Exists(extractPath))
                System.IO.Directory.Delete(extractPath, true);
            System.IO.Directory.CreateDirectory(extractPath);
            
            UnzipFile(zipFile, extractPath);
            
            lblMessage.Text = "解压完成！正在应用更新...";
            
            // 应用更新（复制文件）
            CopyDirectory(extractPath, Server.MapPath("~/"));
            
            // 更新版本号到 changelog.xml（与 index.aspx 保持一致）
            string newVersion = ViewState["LatestVersion"] as string;
            UpdateChangelogVersion(newVersion);
            
            // 同时更新 version.txt（向后兼容）
            string versionFile = Server.MapPath("~/version.txt");
            System.IO.File.WriteAllText(versionFile, newVersion);
            
            // 清理临时文件
            try
            {
                System.IO.File.Delete(zipFile);
                System.IO.Directory.Delete(extractPath, true);
            }
            catch { } // 忽略清理错误
            
            // 重新加载版本号，确保显示最新版本
            LoadCurrentVersion();
            
            lblMessage.Text = "更新成功！当前版本：" + currentVersion;
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(34, 197, 94);
            
            divUpdateInfo.Visible = false;
            btnDownloadUpdate.Visible = false;
            
            // 3秒后刷新页面
            Response.AddHeader("Refresh", "3;URL=" + Request.Url.AbsolutePath);
        }
        catch (Exception ex)
        {
            lblMessage.Text = "更新失败：" + ex.Message;
            lblMessage.ForeColor = System.Drawing.Color.FromArgb(239, 68, 68);
        }
    }
    
    private void UnzipFile(string zipPath, string extractPath)
    {
        try
        {
            // 方法1：使用Shell.Application COM对象（Windows内置）
            Type shellType = Type.GetTypeFromProgID("Shell.Application");
            object shell = Activator.CreateInstance(shellType);
            
            object zipFolder = shellType.InvokeMember("NameSpace",
                System.Reflection.BindingFlags.InvokeMethod, null, shell,
                new object[] { zipPath });
            
            object destFolder = shellType.InvokeMember("NameSpace",
                System.Reflection.BindingFlags.InvokeMethod, null, shell,
                new object[] { extractPath });
            
            object items = zipFolder.GetType().InvokeMember("Items",
                System.Reflection.BindingFlags.InvokeMethod, null, zipFolder, null);
            
            destFolder.GetType().InvokeMember("CopyHere",
                System.Reflection.BindingFlags.InvokeMethod, null, destFolder,
                new object[] { items, 20 }); // 20 = 不显示对话框 + 覆盖已存在文件
            
            // 等待解压完成
            System.Threading.Thread.Sleep(2000);
        }
        catch
        {
            // 方法2：如果COM方法失败，尝试使用ICSharpCode.SharpZipLib（如果已安装）
            try
            {
                System.Reflection.Assembly zipLib = System.Reflection.Assembly.Load("ICSharpCode.SharpZipLib");
                if (zipLib != null)
                {
                    Type fastZipType = zipLib.GetType("ICSharpCode.SharpZipLib.Zip.FastZip");
                    object fastZip = Activator.CreateInstance(fastZipType);
                    fastZipType.InvokeMember("ExtractZip",
                        System.Reflection.BindingFlags.InvokeMethod, null, fastZip,
                        new object[] { zipPath, extractPath, null });
                }
            }
            catch
            {
                throw new Exception("无法解压更新包。请确保系统支持ZIP解压功能，或手动安装更新。");
            }
        }
    }
    
    private void CopyDirectory(string sourceDir, string targetDir)
    {
        System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(sourceDir);
        System.IO.DirectoryInfo[] dirs = dir.GetDirectories();
        
        if (!System.IO.Directory.Exists(targetDir))
            System.IO.Directory.CreateDirectory(targetDir);
        
        System.IO.FileInfo[] files = dir.GetFiles();
        foreach (System.IO.FileInfo file in files)
        {
            string targetFile = System.IO.Path.Combine(targetDir, file.Name);
            try
            {
                file.CopyTo(targetFile, true);
            }
            catch { } // 跳过无法覆盖的文件
        }
        
        foreach (System.IO.DirectoryInfo subdir in dirs)
        {
            string targetSubDir = System.IO.Path.Combine(targetDir, subdir.Name);
            CopyDirectory(subdir.FullName, targetSubDir);
        }
    }
    
    private string ExtractJsonValue(string json, string key)
    {
        try
        {
            string pattern = "\"" + key + "\"\\s*:\\s*\"([^\"]+)\"";
            System.Text.RegularExpressions.Match match = System.Text.RegularExpressions.Regex.Match(json, pattern);
            if (match.Success)
                return match.Groups[1].Value;
        }
        catch { }
        return "";
    }
    
    private int CompareVersion(string v1, string v2)
    {
        try
        {
            // 移除 'v' 前缀
            v1 = v1.TrimStart('v', 'V');
            v2 = v2.TrimStart('v', 'V');
            
            string[] parts1 = v1.Split('.');
            string[] parts2 = v2.Split('.');
            int maxLen = System.Math.Max(parts1.Length, parts2.Length);
            
            for (int i = 0; i < maxLen; i++)
            {
                int num1 = i < parts1.Length ? int.Parse(parts1[i]) : 0;
                int num2 = i < parts2.Length ? int.Parse(parts2[i]) : 0;
                
                if (num1 > num2) return 1;
                if (num1 < num2) return -1;
            }
            return 0;
        }
        catch
        {
            return 0;
        }
    }
    
    private void UpdateChangelogVersion(string newVersion)
    {
        try
        {
            string xmlPath = Server.MapPath("~/changelog.xml");
            if (!System.IO.File.Exists(xmlPath))
            {
                // 如果 changelog.xml 不存在，创建一个基本的
                CreateBasicChangelog(xmlPath, newVersion);
                return;
            }
            
            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
            doc.Load(xmlPath);
            
            System.Xml.XmlNode root = doc.SelectSingleNode("//changelog");
            if (root == null)
            {
                CreateBasicChangelog(xmlPath, newVersion);
                return;
            }
            
            // 检查是否已存在该版本
            System.Xml.XmlNode existingVersion = root.SelectSingleNode("version[@ver='" + newVersion + "']");
            if (existingVersion != null)
            {
                // 版本已存在，不需要添加
                return;
            }
            
            // 创建新版本节点
            System.Xml.XmlElement versionEl = doc.CreateElement("version");
            versionEl.SetAttribute("ver", newVersion);
            versionEl.SetAttribute("tag", "new");
            versionEl.SetAttribute("date", System.DateTime.Now.ToString("yyyy年M月"));
            
            // 添加更新说明
            string updateLogText = ViewState["UpdateLog"] as string;
            if (!string.IsNullOrEmpty(updateLogText))
            {
                string[] lines = updateLogText.Split(new char[] { '\r', '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
                foreach (string line in lines)
                {
                    string trimmed = line.Trim();
                    if (!string.IsNullOrEmpty(trimmed))
                    {
                        System.Xml.XmlElement itemEl = doc.CreateElement("item");
                        // 移除行首的数字序号和点号
                        trimmed = System.Text.RegularExpressions.Regex.Replace(trimmed, @"^\d+[\.\、]\s*", "");
                        itemEl.InnerText = trimmed;
                        versionEl.AppendChild(itemEl);
                    }
                }
            }
            else
            {
                // 如果没有更新日志，添加默认说明
                System.Xml.XmlElement itemEl = doc.CreateElement("item");
                itemEl.InnerText = "系统自动更新到版本 " + newVersion;
                versionEl.AppendChild(itemEl);
            }
            
            // 插入到第一个位置（最新版本在最前面）
            if (root.FirstChild != null)
                root.InsertBefore(versionEl, root.FirstChild);
            else
                root.AppendChild(versionEl);
            
            doc.Save(xmlPath);
        }
        catch { }
    }
    
    private void CreateBasicChangelog(string xmlPath, string version)
    {
        try
        {
            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
            System.Xml.XmlDeclaration declaration = doc.CreateXmlDeclaration("1.0", "utf-8", null);
            doc.AppendChild(declaration);
            
            System.Xml.XmlElement root = doc.CreateElement("changelog");
            doc.AppendChild(root);
            
            System.Xml.XmlElement versionEl = doc.CreateElement("version");
            versionEl.SetAttribute("ver", version);
            versionEl.SetAttribute("tag", "new");
            versionEl.SetAttribute("date", System.DateTime.Now.ToString("yyyy年M月"));
            
            System.Xml.XmlElement itemEl = doc.CreateElement("item");
            itemEl.InnerText = "系统初始化版本";
            versionEl.AppendChild(itemEl);
            
            root.AppendChild(versionEl);
            doc.Save(xmlPath);
        }
        catch { }
    }
</script>

<asp:Content ID="Content1" ContentPlaceHolderID="Content" Runat="Server">
<style>
    .su-page{max-width:100%;padding:28px 32px 40px;font-family:'Microsoft YaHei','Segoe UI',-apple-system,Arial,sans-serif;}
    .su-hd{display:flex;align-items:center;gap:16px;margin-bottom:24px;}
    .su-hd-icon{width:48px;height:48px;background:linear-gradient(135deg,#3b82f6,#6366f1);border-radius:14px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(59,130,246,.25);flex-shrink:0;}
    .su-hd-icon svg{width:26px;height:26px;stroke:#fff;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;}
    .su-hd-text h1{font-size:22px;font-weight:700;color:#0f172a;margin:0 0 2px;}
    .su-hd-text p{font-size:13px;color:#94a3b8;margin:0;}
    .su-grid{display:flex;flex-direction:column;gap:24px;}
    .su-card{background:#fff;border-radius:14px;border:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.04);overflow:hidden;}
    .su-card-hd{padding:16px 22px;font-size:15px;font-weight:600;color:#1e293b;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:12px;}
    .su-card-hd .ci{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .su-card-hd .ci svg{width:19px;height:19px;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;fill:none;}
    .ci.blue{background:#eff6ff;} .ci.blue svg{stroke:#3b82f6;}
    .ci.green{background:#f0fdf4;} .ci.green svg{stroke:#22c55e;}
    .ci.amber{background:#fffbeb;} .ci.amber svg{stroke:#f59e0b;}
    .su-card-bd{padding:22px;}
    .su-form-row{display:flex;flex-direction:column;gap:10px;margin-bottom:18px;}
    .su-form-row label{font-size:13px;font-weight:600;color:#334155;}
    .su-form-row input[type="text"]{width:100%;padding:10px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;font-family:inherit;transition:all .2s;}
    .su-form-row input[type="text"]:focus{outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.1);}
    .su-version-info{display:flex;align-items:center;gap:20px;flex-wrap:wrap;margin-bottom:18px;}
    .su-version-badge{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;}
    .su-version-badge .label{color:#94a3b8;font-size:13px;}
    .su-version-badge .value{color:#1e293b;font-weight:600;}
    .su-btn-group{display:flex;align-items:center;gap:12px;flex-wrap:wrap;}
    .btn-primary{display:inline-flex;align-items:center;justify-content:center;height:40px;padding:0 28px;background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff!important;border:none;border-radius:9px;font-size:14px;font-family:inherit;font-weight:600;cursor:pointer;transition:all .2s;box-shadow:0 2px 8px rgba(59,130,246,.3);}
    .btn-primary:hover{box-shadow:0 4px 16px rgba(59,130,246,.4);transform:translateY(-1px);}
    .btn-success{background:linear-gradient(135deg,#22c55e,#16a34a);box-shadow:0 2px 8px rgba(34,197,94,.3);}
    .btn-success:hover{box-shadow:0 4px 16px rgba(34,197,94,.4);}
    .su-message{margin-top:14px;padding:12px 16px;border-radius:8px;font-size:13px;font-weight:500;}
    .su-update-info{background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:18px;margin-top:18px;}
    .su-update-info h3{font-size:15px;font-weight:600;color:#0c4a6e;margin:0 0 12px;}
    .su-update-info .version{font-size:18px;font-weight:700;color:#0369a1;margin-bottom:12px;}
    .su-update-info .changelog{font-size:13px;color:#334155;line-height:1.8;}
    .su-notice{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:12px;}
    .su-notice li{display:flex;align-items:flex-start;gap:10px;font-size:13px;color:#334155;line-height:1.7;}
    .su-notice li .ni{width:22px;height:22px;border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:11px;font-weight:700;}
    .ni.info{background:#e0f2fe;color:#0369a1;}
    .ni.warn{background:#fef3c7;color:#b45309;}
</style>

<div class="su-page">
    <div class="su-hd">
        <div class="su-hd-icon"><svg viewBox="0 0 24 24"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></div>
        <div class="su-hd-text"><h1>系统更新</h1><p>一键检查并更新系统到最新版本</p></div>
    </div>

    <div class="su-grid">
        <!-- 版本信息 -->
        <div class="su-card">
            <div class="su-card-hd">
                <span class="ci blue"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg></span>
                版本信息
            </div>
            <div class="su-card-bd">
                <div class="su-version-info">
                    <div class="su-version-badge">
                        <span class="label">当前版本：</span>
                        <span class="value"><%= currentVersion %></span>
                    </div>
                </div>
                
                <div class="su-form-row">
                    <label>更新服务器地址（可选）</label>
                    <asp:TextBox ID="txtUpdateUrl" runat="server" placeholder="留空使用本地 version.json 文件"></asp:TextBox>
                    <small style="color:#94a3b8;font-size:12px;margin-top:4px;line-height:1.6;">
                        <strong>三种更新方式：</strong><br/>
                        1. <strong>本地更新</strong>（推荐）：留空此框，将 version.json 放在网站根目录<br/>
                        2. <strong>自建服务器</strong>：输入您的更新服务器地址，如 http://192.168.1.100/updates/version.json<br/>
                        3. <strong>GitHub托管</strong>：使用 GitHub Raw URL<br/>
                        <br/>
                        <span style="color:#f59e0b;">⚠ 注意：旧的 update.lequw.net 地址已不可用，请勿使用</span>
                    </small>
                </div>
                
                <div class="su-btn-group">
                    <asp:Button ID="btnCheckUpdate" runat="server" Text="检查更新" CssClass="btn-primary" OnClick="BtnCheckUpdate_Click" />
                    <asp:Button ID="btnDownloadUpdate" runat="server" Text="立即更新" CssClass="btn-primary btn-success" OnClick="BtnDownloadUpdate_Click" Visible="false" />
                </div>
                
                <div class="su-message">
                    <asp:Label ID="lblMessage" runat="server"></asp:Label>
                </div>
                
                <div id="divUpdateInfo" runat="server" class="su-update-info" visible="false">
                    <h3>发现新版本</h3>
                    <div class="version">v<asp:Literal ID="litLatestVersion" runat="server"></asp:Literal></div>
                    <div class="changelog">
                        <strong>更新内容：</strong><br/>
                        <asp:Literal ID="litUpdateLog" runat="server"></asp:Literal>
                    </div>
                    <div style="margin-top:14px;font-size:12px;color:#64748b;">
                        <asp:HyperLink ID="lnkManualDownload" runat="server" Target="_blank" style="color:#3b82f6;text-decoration:underline;">手动下载更新包</asp:HyperLink>
                    </div>
                </div>
            </div>
        </div>

        <!-- 使用说明 -->
        <div class="su-card">
            <div class="su-card-hd">
                <span class="ci amber"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></span>
                使用说明
            </div>
            <div class="su-card-bd">
                <ul class="su-notice">
                    <li><span class="ni info">1</span>点击「检查更新」按钮，系统将连接到更新服务器检查是否有新版本</li>
                    <li><span class="ni info">2</span>如果有新版本，系统会显示更新内容和版本号</li>
                    <li><span class="ni info">3</span>点击「立即更新」按钮，系统将自动下载并安装更新</li>
                    <li><span class="ni warn">⚠</span>更新前建议先在「数据备份」菜单中备份数据库</li>
                    <li><span class="ni warn">⚠</span>更新过程中请勿关闭浏览器或刷新页面</li>
                    <li><span class="ni info">💡</span>如果自动更新失败，可以手动下载更新包解压后覆盖到网站目录</li>
                </ul>
            </div>
        </div>
    </div>
</div>
</asp:Content>
