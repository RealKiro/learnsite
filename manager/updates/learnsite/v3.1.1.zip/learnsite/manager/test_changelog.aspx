<%@ Page Language="C#" %>
<%@ Import Namespace="System.Xml" %>
<%@ Import Namespace="System.IO" %>

<script runat="server">
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/html; charset=utf-8";
        Response.Write("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Changelog 测试</title>");
        Response.Write("<style>body{font-family:monospace;padding:20px;} .ok{color:green;} .err{color:red;} .info{color:blue;} pre{background:#f5f5f5;padding:10px;border-radius:5px;}</style>");
        Response.Write("</head><body><h1>Changelog 测试诊断</h1>");
        
        // Test 1: Check file path
        string xmlPath = Server.MapPath("~/changelog.xml");
        Response.Write("<h2>测试 1: 文件路径</h2>");
        Response.Write("<p class='info'>路径: " + Server.HtmlEncode(xmlPath) + "</p>");
        
        // Test 2: Check file exists
        Response.Write("<h2>测试 2: 文件是否存在</h2>");
        bool exists = File.Exists(xmlPath);
        Response.Write("<p class='" + (exists ? "ok" : "err") + "'>" + (exists ? "✓ 文件存在" : "✗ 文件不存在") + "</p>");
        
        if (!exists)
        {
            Response.Write("<p class='err'>请确保 changelog.xml 文件在网站根目录</p>");
            Response.Write("</body></html>");
            return;
        }
        
        // Test 3: Read file content
        Response.Write("<h2>测试 3: 读取文件内容</h2>");
        try
        {
            string content = File.ReadAllText(xmlPath, System.Text.Encoding.UTF8);
            Response.Write("<p class='ok'>✓ 文件读取成功，大小: " + content.Length + " 字节</p>");
            Response.Write("<details><summary>查看原始内容（点击展开）</summary><pre>" + Server.HtmlEncode(content.Substring(0, Math.Min(1000, content.Length))) + (content.Length > 1000 ? "..." : "") + "</pre></details>");
        }
        catch (Exception ex)
        {
            Response.Write("<p class='err'>✗ 读取失败: " + Server.HtmlEncode(ex.Message) + "</p>");
            Response.Write("</body></html>");
            return;
        }
        
        // Test 4: Parse XML
        Response.Write("<h2>测试 4: 解析 XML</h2>");
        try
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(xmlPath);
            Response.Write("<p class='ok'>✓ XML 解析成功</p>");
            
            // Test 5: Find versions
            Response.Write("<h2>测试 5: 查找版本节点</h2>");
            XmlNodeList versions = doc.SelectNodes("//changelog/version");
            if (versions == null || versions.Count == 0)
            {
                Response.Write("<p class='err'>✗ 未找到版本节点</p>");
                Response.Write("<p>尝试其他路径...</p>");
                
                // Try alternative paths
                XmlNodeList alt1 = doc.SelectNodes("/changelog/version");
                Response.Write("<p>/changelog/version: " + (alt1 != null ? alt1.Count + " 个节点" : "null") + "</p>");
                
                XmlNodeList alt2 = doc.SelectNodes("//version");
                Response.Write("<p>//version: " + (alt2 != null ? alt2.Count + " 个节点" : "null") + "</p>");
                
                XmlNode root = doc.DocumentElement;
                Response.Write("<p>根节点名称: " + (root != null ? root.Name : "null") + "</p>");
                if (root != null)
                {
                    Response.Write("<p>根节点子节点数: " + root.ChildNodes.Count + "</p>");
                }
            }
            else
            {
                Response.Write("<p class='ok'>✓ 找到 " + versions.Count + " 个版本</p>");
                
                // Test 6: Parse version details
                Response.Write("<h2>测试 6: 解析版本详情</h2>");
                int count = 0;
                foreach (XmlNode vNode in versions)
                {
                    count++;
                    if (count > 3) break; // Only show first 3
                    
                    string ver = vNode.Attributes["ver"] != null ? vNode.Attributes["ver"].Value : "无";
                    string tag = vNode.Attributes["tag"] != null ? vNode.Attributes["tag"].Value : "无";
                    string date = vNode.Attributes["date"] != null ? vNode.Attributes["date"].Value : "无";
                    
                    Response.Write("<div style='border:1px solid #ddd;padding:10px;margin:10px 0;border-radius:5px;'>");
                    Response.Write("<p><strong>版本 " + count + ":</strong></p>");
                    Response.Write("<p>版本号: " + Server.HtmlEncode(ver) + "</p>");
                    Response.Write("<p>标签: " + Server.HtmlEncode(tag) + "</p>");
                    Response.Write("<p>日期: " + Server.HtmlEncode(date) + "</p>");
                    
                    XmlNodeList items = vNode.SelectNodes("item");
                    Response.Write("<p>更新项: " + (items != null ? items.Count : 0) + " 条</p>");
                    
                    if (items != null && items.Count > 0)
                    {
                        Response.Write("<ul>");
                        int itemCount = 0;
                        foreach (XmlNode iNode in items)
                        {
                            itemCount++;
                            if (itemCount > 3) break;
                            string itemType = iNode.Attributes["type"] != null ? iNode.Attributes["type"].Value : "";
                            string itemText = iNode.InnerText;
                            Response.Write("<li>[" + itemType + "] " + Server.HtmlEncode(itemText) + "</li>");
                        }
                        if (items.Count > 3)
                        {
                            Response.Write("<li>... 还有 " + (items.Count - 3) + " 条</li>");
                        }
                        Response.Write("</ul>");
                    }
                    
                    Response.Write("</div>");
                }
                
                if (versions.Count > 3)
                {
                    Response.Write("<p class='info'>... 还有 " + (versions.Count - 3) + " 个版本未显示</p>");
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<p class='err'>✗ XML 解析失败: " + Server.HtmlEncode(ex.Message) + "</p>");
            Response.Write("<pre>" + Server.HtmlEncode(ex.StackTrace) + "</pre>");
        }
        
        Response.Write("<hr><p><a href='index.aspx'>返回管理后台首页</a></p>");
        Response.Write("</body></html>");
    }
</script>
