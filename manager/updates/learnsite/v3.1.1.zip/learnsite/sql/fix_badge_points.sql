-- =============================================
-- 修复徽章积分显示问题
-- 确保所有积分字段都有默认值，不为NULL
-- =============================================

-- 1. 修复Badge表中的NULL积分值
UPDATE Badge 
SET Bpoints = 0 
WHERE Bpoints IS NULL;

-- 2. 修复BadgeExchange表中的NULL积分值
UPDATE BadgeExchange 
SET Epoints = 0 
WHERE Epoints IS NULL;

-- 3. 确保Badge表的Bpoints字段有默认值约束
IF NOT EXISTS (
    SELECT * FROM sys.default_constraints 
    WHERE parent_object_id = OBJECT_ID('Badge') 
    AND parent_column_id = (
        SELECT column_id FROM sys.columns 
        WHERE object_id = OBJECT_ID('Badge') 
        AND name = 'Bpoints'
    )
)
BEGIN
    ALTER TABLE Badge ADD CONSTRAINT DF_Badge_Bpoints DEFAULT (0) FOR Bpoints;
END

-- 4. 确保BadgeExchange表的Epoints字段有默认值约束
IF NOT EXISTS (
    SELECT * FROM sys.default_constraints 
    WHERE parent_object_id = OBJECT_ID('BadgeExchange') 
    AND parent_column_id = (
        SELECT column_id FROM sys.columns 
        WHERE object_id = OBJECT_ID('BadgeExchange') 
        AND name = 'Epoints'
    )
)
BEGIN
    ALTER TABLE BadgeExchange ADD CONSTRAINT DF_BadgeExchange_Epoints DEFAULT (0) FOR Epoints;
END

-- 5. 验证修复结果
SELECT 
    '修复完成' AS 状态,
    (SELECT COUNT(*) FROM Badge WHERE Bpoints IS NULL) AS Badge表NULL积分数,
    (SELECT COUNT(*) FROM BadgeExchange WHERE Epoints IS NULL) AS BadgeExchange表NULL积分数,
    (SELECT COUNT(*) FROM Badge) AS Badge表总记录数,
    (SELECT COUNT(*) FROM BadgeExchange) AS BadgeExchange表总记录数;

PRINT '徽章积分修复完成！';
