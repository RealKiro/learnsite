<%@ WebHandler Language="C#" Class="CaptchaHandler" %>

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Web;
using System.Web.SessionState;

public class CaptchaHandler : IHttpHandler, IRequiresSessionState
{
    public void ProcessRequest(HttpContext context)
    {
        // 获取验证码类型
        string type = context.Request.QueryString["type"];
        string sessionKey = "TeacherCaptcha"; // 默认登录验证码
        
        if (!string.IsNullOrEmpty(type))
        {
            if (type.Equals("email", StringComparison.OrdinalIgnoreCase))
            {
                sessionKey = "EmailCaptcha";
            }
        }
        
        // 生成随机验证码
        string code = GenerateRandomCode(4);
        
        // 保存到Session
        context.Session[sessionKey] = code;
        context.Session.Timeout = 10; // 10分钟过期
        
        // 生成图片
        Bitmap bitmap = GenerateCaptchaImage(code);
        
        // 输出图片
        context.Response.ContentType = "image/png";
        context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        context.Response.Cache.SetNoStore();
        context.Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
        
        bitmap.Save(context.Response.OutputStream, ImageFormat.Png);
        bitmap.Dispose();
    }
    
    private string GenerateRandomCode(int length)
    {
        // 使用数字和大写字母，排除容易混淆的字符
        string chars = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
        Random random = new Random();
        char[] code = new char[length];
        
        for (int i = 0; i < length; i++)
        {
            code[i] = chars[random.Next(chars.Length)];
        }
        
        return new string(code);
    }
    
    private Bitmap GenerateCaptchaImage(string code)
    {
        int width = 120;
        int height = 40;
        
        Bitmap bitmap = new Bitmap(width, height);
        Graphics g = Graphics.FromImage(bitmap);
        
        try
        {
            // 设置高质量渲染
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            
            // 背景渐变
            LinearGradientBrush brush = new LinearGradientBrush(
                new Rectangle(0, 0, width, height),
                Color.FromArgb(240, 243, 250),
                Color.FromArgb(230, 235, 245),
                LinearGradientMode.Vertical);
            g.FillRectangle(brush, 0, 0, width, height);
            
            // 添加噪点
            Random random = new Random();
            for (int i = 0; i < 50; i++)
            {
                int x = random.Next(width);
                int y = random.Next(height);
                int size = random.Next(1, 3);
                Color color = Color.FromArgb(random.Next(100, 200), random.Next(100, 200), random.Next(100, 200));
                g.FillEllipse(new SolidBrush(color), x, y, size, size);
            }
            
            // 添加干扰线
            for (int i = 0; i < 3; i++)
            {
                int x1 = random.Next(width);
                int y1 = random.Next(height);
                int x2 = random.Next(width);
                int y2 = random.Next(height);
                Color color = Color.FromArgb(random.Next(150, 220), random.Next(150, 220), random.Next(150, 220));
                g.DrawLine(new Pen(color, 1), x1, y1, x2, y2);
            }
            
            // 绘制验证码文字（控制在图片范围内，避免被裁剪）
            Font font = new Font("Arial", 20, FontStyle.Bold);
            int charWidth = width / code.Length;
            
            for (int i = 0; i < code.Length; i++)
            {
                // 随机颜色
                Color color = Color.FromArgb(
                    random.Next(50, 120),
                    random.Next(50, 120),
                    random.Next(50, 120));
                
                // 随机位置和角度（在高度范围内略微上下浮动）
                float x = i * charWidth + random.Next(5, 10);
                // 让字符垂直居中附近，再做轻微随机偏移，避免超出 0~height 范围
                float y = (height - font.Size) / 2 + random.Next(-4, 5);
                float angle = random.Next(-15, 15);
                
                // 保存当前状态
                GraphicsState state = g.Save();
                
                // 以字符当前位置为原点进行轻微旋转，再绘制
                g.TranslateTransform(x, y);
                g.RotateTransform(angle);
                g.DrawString(code[i].ToString(), font, new SolidBrush(color), 0, 0);
                
                // 恢复状态
                g.Restore(state);
            }
            
            // 边框
            g.DrawRectangle(new Pen(Color.FromArgb(200, 210, 225), 1), 0, 0, width - 1, height - 1);
        }
        finally
        {
            g.Dispose();
        }
        
        return bitmap;
    }
    
    public bool IsReusable
    {
        get { return false; }
    }
}
