<%@ Page Language="C#" MasterPageFile="~/teacher/Teach.master" AutoEventWireup="true" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.IO" %>

<script runat="server">
    private string GetConnStr()
    {
        string cs = null;
        try
        {
            Type dbType = typeof(LearnSite.Common.CookieHelp).Assembly.GetType("LearnSite.DBUtility.DbHelperSQL");
            if (dbType != null)
            {
                System.Reflection.FieldInfo f = dbType.GetField("connectionString",
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                if (f != null) cs = f.GetValue(null) as string;
            }
        }
        catch { }
        if (string.IsNullOrEmpty(cs))
        { try { cs = System.Configuration.ConfigurationManager.ConnectionStrings["SqlServer"].ConnectionString; } catch { } }
        if (cs != null && cs.ToLower().IndexOf("connection timeout") < 0 && cs.ToLower().IndexOf("connect timeout") < 0)
            cs = cs.TrimEnd(';') + ";Connection Timeout=5;";
        return cs;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadCategories();
        }
    }

    private string GetResourceType(string fileName)
    {
        string ext = Path.GetExtension(fileName).ToLower();
        
        string[] videoExts = new string[] { ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v" };
        string[] audioExts = new string[] { ".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a" };
        string[] imageExts = new string[] { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp" };
        string[] docExts = new string[] { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt" };
        string[] codeExts = new string[] { ".html", ".css", ".js", ".py", ".java", ".cpp", ".c", ".cs", ".php" };
        string[] archiveExts = new string[] { ".zip", ".rar", ".7z", ".tar", ".gz" };
        
        foreach (string e in videoExts) { if (ext == e) return "视频"; }
        foreach (string e in audioExts) { if (ext == e) return "音频"; }
        foreach (string e in imageExts) { if (ext == e) return "图片"; }
        foreach (string e in docExts) { if (ext == e) return "文档"; }
        foreach (string e in codeExts) { if (ext == e) return "代码"; }
        foreach (string e in archiveExts) { if (ext == e) return "压缩包"; }
        
        return "其他";
    }

    protected void LoadCategories()
    {
        string connStr = GetConnStr();
        if (string.IsNullOrEmpty(connStr)) return;
        
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string sql = "SELECT CategoryId, CategoryName FROM ResourceCategories WHERE IsActive = 1 ORDER BY SortOrder";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            ddlCategory.DataSource = dt;
            ddlCategory.DataTextField = "CategoryName";
            ddlCategory.DataValueField = "CategoryId";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, new System.Web.UI.WebControls.ListItem("请选择分类", "0"));
        }
    }

    protected void btnCreate_Click(object sender, EventArgs e)
    {
        string resourceName = txtResourceName.Text.Trim();
        if (string.IsNullOrEmpty(resourceName))
        {
            ShowMessage("请输入资源名称", "error");
            return;
        }
        
        if (ddlCategory.SelectedValue == "0")
        {
            ShowMessage("请选择资源分类", "error");
            return;
        }
        
        if (!fileUploadResource.HasFile)
        {
            ShowMessage("请上传资源文件", "error");
            return;
        }
        
        try
        {
            string connStr = GetConnStr();
            if (string.IsNullOrEmpty(connStr))
            {
                ShowMessage("数据库连接失败", "error");
                return;
            }
            
            string coverImagePath = "";
            if (fileUploadCover.HasFile)
            {
                string coverDir = Server.MapPath("~/uploads/covers/");
                if (!Directory.Exists(coverDir)) Directory.CreateDirectory(coverDir);
                
                string coverExt = Path.GetExtension(fileUploadCover.FileName);
                string coverFileName = DateTime.Now.ToString("yyyyMMddHHmmss") + "_cover" + coverExt;
                string coverPhysicalPath = Path.Combine(coverDir, coverFileName);
                fileUploadCover.SaveAs(coverPhysicalPath);
                coverImagePath = "/uploads/covers/" + coverFileName;
            }
            
            string resourceDir = Server.MapPath("~/uploads/resources/");
            if (!Directory.Exists(resourceDir)) Directory.CreateDirectory(resourceDir);
            
            string resourceExt = Path.GetExtension(fileUploadResource.FileName);
            string resourceFileName = DateTime.Now.ToString("yyyyMMddHHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + resourceExt;
            string resourcePhysicalPath = Path.Combine(resourceDir, resourceFileName);
            fileUploadResource.SaveAs(resourcePhysicalPath);
            string resourceRelativePath = "/uploads/resources/" + resourceFileName;
            
            long fileSize = fileUploadResource.PostedFile.ContentLength;
            string resourceType = GetResourceType(fileUploadResource.FileName);
            
            string userSnum = "admin";
            try
            {
                HttpCookie tc = Request.Cookies[LearnSite.Common.CookieHelp.teaCookieNname];
                if (tc != null && !string.IsNullOrEmpty(tc.Value))
                {
                    object t = DecodeCookie("LearnSite.Model.TeaCook", tc.Value);
                    userSnum = GetProp(t, "Hname");
                }
            }
            catch { }
            
            int viewCredits = 0;
            int downloadCredits = 0;
            int.TryParse(txtViewCredits.Text.Trim(), out viewCredits);
            int.TryParse(txtDownloadCredits.Text.Trim(), out downloadCredits);
            
            bool hasChapters = chkHasChapters.Checked;
            
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                
                string sql = @"INSERT INTO Files (FileName, FileSize, CreateTime, UpdateTime, RelativePath, UserSnum, FolderId,
                              ResourceName, CategoryId, CoverImage, ViewCredits, DownloadCredits, Description, 
                              ResourceType, ViewCount, DownloadCount, HasChapters, IsPublished)
                              VALUES (@FileName, @FileSize, @CreateTime, @UpdateTime, @RelativePath, @UserSnum, 0,
                              @ResourceName, @CategoryId, @CoverImage, @ViewCredits, @DownloadCredits, @Description,
                              @ResourceType, 0, 0, @HasChapters, 1);
                              SELECT SCOPE_IDENTITY();";
                
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@FileName", fileUploadResource.FileName);
                cmd.Parameters.AddWithValue("@FileSize", fileSize);
                cmd.Parameters.AddWithValue("@CreateTime", DateTime.Now);
                cmd.Parameters.AddWithValue("@UpdateTime", DateTime.Now);
                cmd.Parameters.AddWithValue("@RelativePath", resourceRelativePath);
                cmd.Parameters.AddWithValue("@UserSnum", userSnum);
                cmd.Parameters.AddWithValue("@ResourceName", resourceName);
                cmd.Parameters.AddWithValue("@CategoryId", ddlCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@CoverImage", coverImagePath);
                cmd.Parameters.AddWithValue("@ViewCredits", viewCredits);
                cmd.Parameters.AddWithValue("@DownloadCredits", downloadCredits);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text.Trim());
                cmd.Parameters.AddWithValue("@ResourceType", resourceType);
                cmd.Parameters.AddWithValue("@HasChapters", hasChapters);
                
                int resourceId = Convert.ToInt32(cmd.ExecuteScalar());
                
                txtResourceName.Text = "";
                txtDescription.Text = "";
                txtViewCredits.Text = "0";
                txtDownloadCredits.Text = "0";
                ddlCategory.SelectedIndex = 0;
                chkHasChapters.Checked = false;
                
                if (hasChapters)
                {
                    ShowMessageAndRedirect("资源创建成功！正在跳转到章节管理...", "success", "resourcechapters.aspx?rid=" + resourceId);
                }
                else
                {
                    ShowMessageAndRedirect("资源创建成功！正在跳转到资源管理...", "success", "resourcemanage.aspx");
                }
            }
        }
        catch (Exception ex)
        {
            ShowMessage("创建失败：" + ex.Message, "error");
        }
    }
    
    private void ShowMessage(string message, string type)
    {
        string script = string.Format("showToast('{0}', '{1}');", message.Replace("'", "\\'"), type);
        ClientScript.RegisterStartupScript(this.GetType(), "toast", script, true);
    }
    
    private void ShowMessageAndRedirect(string message, string type, string url)
    {
        string script = string.Format("showToast('{0}', '{1}'); setTimeout(function(){{ window.location.href='{2}'; }}, 1500);", 
            message.Replace("'", "\\'"), type, url);
        ClientScript.RegisterStartupScript(this.GetType(), "toastRedirect", script, true);
    }
    
    private static System.Reflection.BindingFlags tFlags =
        System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic
        | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Static;

    private object DecodeCookie(string typeName, string cookieValue)
    {
        Type cookType = typeof(LearnSite.Common.CookieHelp).Assembly.GetType(typeName);
        if (cookType == null) return null;
        object model = Activator.CreateInstance(cookType);
        System.Reflection.MethodInfo toModel = cookType.GetMethod("ToModel", tFlags);
        if (toModel != null) toModel.Invoke(model, new object[] { cookieValue });
        return model;
    }

    private string GetProp(object model, string propName)
    {
        if (model == null) return "";
        System.Reflection.PropertyInfo prop = model.GetType().GetProperty(propName);
        if (prop == null) return "";
        object val = prop.GetValue(model, null);
        return val != null ? val.ToString() : "";
    }

</script>

<asp:Content ID="Content1" ContentPlaceHolderID="Content" runat="server">
<style>
    * { box-sizing: border-box; }
    .create-container { max-width: 1600px; margin: 0 auto; }
    
    .page-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px; padding: 40px; margin-bottom: 32px;
        color: white; box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
        position: relative; overflow: hidden;
    }
    .page-header::before {
        content: ''; position: absolute; top: -50%; right: -10%;
        width: 400px; height: 400px; border-radius: 50%;
        background: rgba(255,255,255,0.1);
    }
    .page-header h1 { 
        margin: 0 0 12px 0; font-size: 32px; font-weight: 700;
        position: relative; z-index: 1;
    }
    .page-header p { 
        margin: 0; opacity: 0.95; font-size: 15px;
        position: relative; z-index: 1;
    }
    
    .stats-grid-small {
        display: grid; grid-template-columns: repeat(3, 1fr);
        gap: 24px; margin-bottom: 32px;
    }
    .stat-card-small {
        background: white; border-radius: 20px; padding: 28px 32px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        display: flex; align-items: center; gap: 20px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative; overflow: hidden;
        border: 2px solid transparent;
    }
    .stat-card-small::before {
        content: ''; position: absolute; top: -50%; right: -20%;
        width: 150px; height: 150px; border-radius: 50%;
        opacity: 0.08; transition: all 0.5s;
    }
    .stat-card-small::after {
        content: ''; position: absolute; bottom: 0; left: 0;
        width: 100%; height: 4px;
        background: linear-gradient(90deg, transparent, currentColor, transparent);
        opacity: 0; transition: all 0.4s;
    }
    .stat-card-small:hover {
        transform: translateY(-6px) scale(1.02);
        box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        border-color: currentColor;
    }
    .stat-card-small:hover::before {
        transform: scale(1.3) rotate(45deg);
        opacity: 0.12;
    }
    .stat-card-small:hover::after {
        opacity: 0.6;
    }
    .stat-card-small:nth-child(1) { color: #3b82f6; }
    .stat-card-small:nth-child(1)::before { background: #3b82f6; }
    .stat-card-small:nth-child(2) { color: #10b981; }
    .stat-card-small:nth-child(2)::before { background: #10b981; }
    .stat-card-small:nth-child(3) { color: #f59e0b; }
    .stat-card-small:nth-child(3)::before { background: #f59e0b; }
    
    .stat-icon-small {
        width: 56px; height: 56px; border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        font-size: 26px; flex-shrink: 0;
        box-shadow: 0 6px 20px rgba(0,0,0,0.12);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative; z-index: 1;
    }
    .stat-icon-small::before {
        content: ''; position: absolute; inset: -4px;
        border-radius: 18px; opacity: 0;
        background: inherit; filter: blur(8px);
        transition: all 0.4s;
    }
    .stat-card-small:hover .stat-icon-small {
        transform: scale(1.15) rotate(-5deg);
        box-shadow: 0 8px 30px rgba(0,0,0,0.2);
    }
    .stat-card-small:hover .stat-icon-small::before {
        opacity: 0.4;
    }
    .stat-info-small { 
        flex: 1; min-width: 0; position: relative; z-index: 1;
    }
    .stat-value-small {
        font-size: 32px; font-weight: 900; color: #1e293b;
        line-height: 1; letter-spacing: -1.5px;
        margin-bottom: 6px;
        background: linear-gradient(135deg, #1e293b 0%, #475569 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .stat-label-small {
        font-size: 14px; color: #64748b; font-weight: 600;
        letter-spacing: 0.3px;
    }

    .stats-grid-small {
        display: grid; grid-template-columns: repeat(3, 1fr);
        gap: 24px; margin-bottom: 32px;
    }
    .stat-card-small {
        background: white; border-radius: 20px; padding: 28px 32px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        display: flex; align-items: center; gap: 20px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative; overflow: hidden;
        border: 2px solid transparent;
    }
    .stat-card-small::before {
        content: ''; position: absolute; top: -50%; right: -20%;
        width: 150px; height: 150px; border-radius: 50%;
        opacity: 0.08; transition: all 0.5s;
    }
    .stat-card-small::after {
        content: ''; position: absolute; bottom: 0; left: 0;
        width: 100%; height: 4px;
        background: linear-gradient(90deg, transparent, currentColor, transparent);
        opacity: 0; transition: all 0.4s;
    }
    .stat-card-small:hover {
        transform: translateY(-6px) scale(1.02);
        box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        border-color: currentColor;
    }
    .stat-card-small:hover::before {
        transform: scale(1.3) rotate(45deg);
        opacity: 0.12;
    }
    .stat-card-small:hover::after {
        opacity: 0.6;
    }
    .stat-card-small:nth-child(1) { color: #3b82f6; }
    .stat-card-small:nth-child(1)::before { background: #3b82f6; }
    .stat-card-small:nth-child(2) { color: #10b981; }
    .stat-card-small:nth-child(2)::before { background: #10b981; }
    .stat-card-small:nth-child(3) { color: #f59e0b; }
    .stat-card-small:nth-child(3)::before { background: #f59e0b; }
    
    .stat-icon-small {
        width: 56px; height: 56px; border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        font-size: 26px; flex-shrink: 0;
        box-shadow: 0 6px 20px rgba(0,0,0,0.12);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative; z-index: 1;
    }
    .stat-icon-small::before {
        content: ''; position: absolute; inset: -4px;
        border-radius: 18px; opacity: 0;
        background: inherit; filter: blur(8px);
        transition: all 0.4s;
    }
    .stat-card-small:hover .stat-icon-small {
        transform: scale(1.15) rotate(-5deg);
        box-shadow: 0 8px 30px rgba(0,0,0,0.2);
    }
    .stat-card-small:hover .stat-icon-small::before {
        opacity: 0.4;
    }
    .stat-info-small { 
        flex: 1; min-width: 0; position: relative; z-index: 1;
    }
    .stat-value-small {
        font-size: 32px; font-weight: 900; color: #1e293b;
        line-height: 1; letter-spacing: -1.5px;
        margin-bottom: 6px;
        background: linear-gradient(135deg, #1e293b 0%, #475569 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    .stat-label-small {
        font-size: 14px; color: #64748b; font-weight: 600;
        letter-spacing: 0.3px;
    }

    .create-card {
        background: white; border-radius: 20px; padding: 40px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .form-section {
        margin-bottom: 40px; padding-bottom: 40px;
        border-bottom: 2px solid #f1f5f9;
    }
    .form-section:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }
    .section-title {
        font-size: 20px; font-weight: 700; color: #1e293b;
        margin-bottom: 24px; display: flex; align-items: center; gap: 12px;
        padding-bottom: 16px; border-bottom: 2px solid #f1f5f9;
        position: relative; padding-left: 40px;
    }
    .section-title::before {
        content: ''; position: absolute; left: 0;
        width: 28px; height: 28px;
        background-size: contain; background-repeat: no-repeat;
        background-position: center;
    }
    .section-title.section-basic::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23667eea' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'/%3E%3C/svg%3E");
    }
    .section-title.section-credits::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23667eea' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z'/%3E%3C/svg%3E");
    }
    .section-title.section-chapters::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23667eea' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253'/%3E%3C/svg%3E");
    }
    
    .form-group { margin-bottom: 24px; }
    .form-group label {
        display: block; margin-bottom: 10px; font-size: 15px;
        font-weight: 600; color: #475569;
        position: relative; padding-left: 28px;
    }
    .form-group label::before {
        content: ''; position: absolute; left: 0; top: 50%;
        transform: translateY(-50%);
        width: 18px; height: 18px;
        background-size: contain; background-repeat: no-repeat;
        background-position: center;
    }
    .label-name::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z'/%3E%3C/svg%3E");
    }
    .label-category::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z'/%3E%3C/svg%3E");
    }
    .label-desc::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M4 6h16M4 12h16M4 18h7'/%3E%3C/svg%3E");
    }
    .label-upload::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12'/%3E%3C/svg%3E");
    }
    .label-cover::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='3' width='18' height='18' rx='2' ry='2'/%3E%3Ccircle cx='8.5' cy='8.5' r='1.5'/%3E%3Cpolyline points='21 15 16 10 5 21'/%3E%3C/svg%3E");
    }
    .label-view::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M15 12a3 3 0 11-6 0 3 3 0 016 0z'/%3E%3Cpath d='M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z'/%3E%3C/svg%3E");
    }
    .label-download::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10'/%3E%3C/svg%3E");
    }
    .form-group label .required { color: #ef4444; margin-left: 4px; font-size: 16px; }
    
    .form-control {
        width: 100%; padding: 14px 18px; border: 2px solid #e2e8f0;
        border-radius: 12px; font-size: 15px; transition: all 0.3s;
        font-family: inherit; background: #f8fafc;
    }
    .form-control:focus {
        outline: none; border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        background: white;
    }
    textarea.form-control { resize: vertical; min-height: 120px; line-height: 1.6; }
    
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    
    
    .file-upload-box {
        border: 3px dashed #cbd5e1; border-radius: 16px;
        padding: 48px 32px; text-align: center; background: #f8fafc;
        transition: all 0.3s; cursor: pointer; position: relative;
        overflow: hidden;
    }
    .file-upload-box:hover { 
        border-color: #667eea; background: #f1f5f9;
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.15);
    }
    .file-upload-box.has-file {
        border-color: #10b981; 
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        border-style: solid;
        padding: 32px;
    }
    .file-upload-icon {
        width: 80px; height: 80px; margin: 0 auto 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px; display: flex; align-items: center;
        justify-content: center; box-shadow: 0 8px 24px rgba(102, 126, 234, 0.3);
        transition: all 0.3s;
    }
    .file-upload-box:hover .file-upload-icon {
        transform: scale(1.05) translateY(-4px);
    }
    .file-upload-icon svg {
        width: 40px; height: 40px; stroke: white; stroke-width: 2;
    }
    .file-upload-title {
        font-size: 18px; font-weight: 700; color: #1e293b;
        margin-bottom: 8px; transition: all 0.3s;
    }
    .file-upload-text { 
        font-size: 14px; color: #64748b; font-weight: 500;
        line-height: 1.6; transition: all 0.3s;
    }
    .file-upload-hint {
        margin-top: 16px; padding: 12px 20px;
        background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
        border-radius: 10px; font-size: 13px; color: #1e40af;
        font-weight: 600; display: inline-block;
    }
    .file-selected-info {
        display: flex; align-items: center; gap: 20px;
        padding: 24px 28px; background: white;
        border-radius: 16px; border: 2px solid #10b981;
        box-shadow: 0 4px 20px rgba(16, 185, 129, 0.15);
        text-align: left;
    }
    .file-selected-icon-wrapper {
        width: 72px; height: 72px; flex-shrink: 0;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        border-radius: 18px; display: flex; align-items: center;
        justify-content: center; box-shadow: 0 8px 24px rgba(16, 185, 129, 0.3);
        position: relative;
    }
    .file-selected-icon-wrapper::before {
        content: ''; position: absolute; inset: -4px;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        border-radius: 20px; opacity: 0.3; filter: blur(12px);
    }
    .file-selected-icon {
        font-size: 36px; position: relative; z-index: 1;
        animation: checkBounce 0.6s ease;
    }
    @keyframes checkBounce {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.2); }
    }
    .file-selected-details {
        flex: 1; min-width: 0;
    }
    .file-selected-name {
        font-size: 16px; font-weight: 700; color: #059669;
        margin-bottom: 8px; word-break: break-all;
        display: flex; align-items: center; gap: 8px;
    }
    .file-type-badge {
        display: inline-block; padding: 4px 10px;
        background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
        border-radius: 6px; font-size: 12px;
        font-weight: 600; color: #065f46;
        text-transform: uppercase;
    }
    .file-selected-size {
        font-size: 14px; color: #64748b; font-weight: 500;
        display: flex; align-items: center; gap: 6px;
    }
    .file-selected-size svg {
        width: 16px; height: 16px; stroke: #94a3b8;
    }
    .file-change-btn {
        padding: 10px 20px; background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
        border: 2px solid #cbd5e1; border-radius: 10px;
        font-size: 13px; font-weight: 600; color: #475569;
        cursor: pointer; transition: all 0.3s;
        display: flex; align-items: center; gap: 6px;
        white-space: nowrap;
    }
    .file-change-btn:hover {
        background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%);
        border-color: #94a3b8;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    .file-change-btn svg {
        width: 16px; height: 16px; stroke: currentColor;
    }
    
    .file-upload-box-compact {
        border: 2px dashed #cbd5e1; border-radius: 12px;
        padding: 24px; text-align: center; background: #f8fafc;
        transition: all 0.3s; cursor: pointer; position: relative;
        min-height: 120px; display: flex; align-items: center;
        justify-content: center;
    }
    .file-upload-box-compact:hover { 
        border-color: #667eea; background: #f1f5f9;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.1);
    }
    .file-upload-text-compact { 
        font-size: 14px; color: #64748b; font-weight: 500;
        display: flex; align-items: center; justify-content: center; gap: 8px;
    }
    .file-upload-text-compact svg {
        width: 20px; height: 20px; stroke: #94a3b8;
    }
    .cover-preview {
        position: relative; width: 100%; height: 100%;
        border-radius: 8px; overflow: hidden;
    }
    .cover-preview img {
        width: 100%; height: 200px; object-fit: cover;
        display: block; border-radius: 8px;
    }
    .cover-preview-overlay {
        position: absolute; inset: 0;
        background: rgba(0,0,0,0.6);
        display: flex; align-items: center; justify-content: center;
        opacity: 0; transition: all 0.3s;
        color: white; font-size: 15px; font-weight: 600;
    }
    .cover-preview:hover .cover-preview-overlay {
        opacity: 1;
    }
    
    .checkbox-group {
        display: flex; align-items: center; gap: 14px;
        padding: 20px 24px; background: #f8fafc; border-radius: 12px;
        border: 2px solid #e2e8f0; transition: all 0.3s;
        cursor: pointer; user-select: none;
    }
    .checkbox-group:hover { 
        border-color: #cbd5e1; background: #f1f5f9;
    }
    .checkbox-group input[type="checkbox"] {
        width: 22px; height: 22px; cursor: pointer;
        accent-color: #667eea; pointer-events: none;
    }
    .checkbox-label {
        font-size: 15px; font-weight: 600; color: #475569;
        cursor: pointer; user-select: none; flex: 1;
    }
    .checkbox-hint {
        font-size: 13px; color: #94a3b8; margin-left: 36px; margin-top: 8px;
        font-weight: 500;
    }
    
    .btn-create {
        width: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; border: none; padding: 18px 40px;
        border-radius: 14px; font-size: 17px; font-weight: 700;
        cursor: pointer; transition: all 0.3s;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        display: flex; align-items: center; justify-content: center; gap: 10px;
    }
    .btn-create:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.5);
    }
    .btn-create svg {
        width: 22px; height: 22px;
    }
    
    .info-box {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border-left: 4px solid #0284c7;
        padding: 20px 24px; border-radius: 12px; margin-bottom: 24px;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.1);
    }
    .info-box-title {
        font-size: 15px; font-weight: 700; color: #0c4a6e;
        margin-bottom: 10px; position: relative; padding-left: 28px;
    }
    .info-box-title::before {
        content: ''; position: absolute; left: 0; top: 50%;
        transform: translateY(-50%);
        width: 20px; height: 20px;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%230284c7' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z'/%3E%3C/svg%3E");
        background-size: contain; background-repeat: no-repeat;
        background-position: center;
    }
    .info-box-text {
        font-size: 14px; color: #075985; line-height: 1.7; font-weight: 500;
    }
    
    .toast {
        position: fixed; top: 24px; right: 24px; background: white;
        padding: 18px 28px; border-radius: 16px;
        box-shadow: 0 12px 48px rgba(0,0,0,0.2); z-index: 10000;
        display: none; align-items: center; gap: 14px;
        animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        border-left: 4px solid;
    }
    @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    .toast.success { border-left-color: #10b981; }
    .toast.error { border-left-color: #ef4444; }
    .toast-icon { font-size: 24px; }
    .toast-message { font-size: 15px; font-weight: 500; color: #1e293b; }
</style>


<div class="create-container">
    <div class="page-header">
        <h1>✨ 创建资源</h1>
        <p>创建新的教学资源，支持设置分类、封面、积分和多章节内容</p>
    </div>
    
    <div class="create-card">
        <div class="form-section">
            <div class="section-title section-basic">
                基本信息
            </div>
            
            <div class="form-group">
                <label class="label-name">
                    资源名称 <span class="required">*</span>
                </label>
                <asp:TextBox ID="txtResourceName" runat="server" CssClass="form-control" 
                             placeholder="输入资源名称，例如：Python编程入门教程"></asp:TextBox>
            </div>
            
            <div class="form-group">
                <label class="label-category">
                    资源分类 <span class="required">*</span>
                </label>
                <asp:DropDownList ID="ddlCategory" runat="server" CssClass="form-control"></asp:DropDownList>
            </div>
            
            <div class="form-group">
                <label class="label-desc">
                    资源描述
                </label>
                <asp:TextBox ID="txtDescription" runat="server" CssClass="form-control" 
                             TextMode="MultiLine" placeholder="详细描述资源内容、适用对象、学习目标等"></asp:TextBox>
            </div>
            
            <div class="form-group">
                <label class="label-upload">
                    上传资源文件 <span class="required">*</span>
                </label>
                <div class="file-upload-box" id="resourceUploadBox" onclick="document.getElementById('<%= fileUploadResource.ClientID %>').click();">
                    <div class="file-upload-icon" id="resourceUploadIcon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <path d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                        </svg>
                    </div>
                    <div class="file-upload-title" id="resourceUploadTitle">点击选择资源文件</div>
                    <div class="file-upload-text" id="resourceUploadText">
                        支持视频、音频、文档、图片、代码、压缩包等多种格式<br/>
                        系统将自动识别文件类型
                    </div>
                    <div class="file-upload-hint" id="resourceUploadHint">📁 支持格式：MP4, PDF, ZIP, MP3, DOC, PPT 等</div>
                    <div class="file-selected-info" id="resourceFileInfo" style="display: none;">
                        <div class="file-selected-icon-wrapper">
                            <div class="file-selected-icon">✓</div>
                        </div>
                        <div class="file-selected-details">
                            <div class="file-selected-name">
                                <span id="resourceFileName"></span>
                                <span class="file-type-badge" id="resourceFileType"></span>
                            </div>
                            <div class="file-selected-size">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                </svg>
                                <span id="resourceFileSize"></span>
                            </div>
                        </div>
                        <div class="file-change-btn" onclick="event.stopPropagation(); document.getElementById('<%= fileUploadResource.ClientID %>').click();">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                            </svg>
                            更换文件
                        </div>
                    </div>
                </div>
                <asp:FileUpload ID="fileUploadResource" runat="server" style="display: none;" onchange="handleResourceFileSelect(this)" />
            </div>
            
            <div class="form-group">
                <label class="label-cover">
                    资源封面（可选）
                </label>
                <div class="file-upload-box-compact" id="coverUploadBox" onclick="document.getElementById('<%= fileUploadCover.ClientID %>').click();">
                    <div class="cover-preview" id="coverPreview" style="display: none;">
                        <img id="coverPreviewImg" src="" alt="封面预览" />
                        <div class="cover-preview-overlay">
                            <span>点击更换封面</span>
                        </div>
                    </div>
                    <div class="file-upload-text-compact" id="coverUploadText">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>
                        </svg>
                        点击选择封面图片（建议 800x600 或 16:9 比例）
                    </div>
                </div>
                <asp:FileUpload ID="fileUploadCover" runat="server" style="display: none;" onchange="handleCoverFileSelect(this)" accept="image/*" />
            </div>
        </div>
        
        <div class="form-section">
            <div class="section-title section-credits">
                积分设置
            </div>
            
            <div class="info-box">
                <div class="info-box-title">
                    积分说明
                </div>
                <div class="info-box-text">
                    设置学生学习该资源可获得的积分奖励。观看积分：学生观看/浏览资源后获得；下载积分：学生下载资源后获得。
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label class="label-view">
                        观看积分
                    </label>
                    <asp:TextBox ID="txtViewCredits" runat="server" CssClass="form-control" 
                                 Text="0" placeholder="观看/浏览可获得的积分"></asp:TextBox>
                </div>
                
                <div class="form-group">
                    <label class="label-download">
                        下载积分
                    </label>
                    <asp:TextBox ID="txtDownloadCredits" runat="server" CssClass="form-control" 
                                 Text="0" placeholder="下载可获得的积分"></asp:TextBox>
                </div>
            </div>
        </div>
        
        <div class="form-section">
            <div class="section-title section-chapters">
                章节设置
            </div>
            
            <div class="info-box">
                <div class="info-box-title">
                    多章节功能
                </div>
                <div class="info-box-text">
                    如果您的资源包含多个章节（如视频教程系列、分章节的文档等），请勾选此选项。
                    创建资源后，系统会引导您添加各个章节的内容。
                </div>
            </div>
            
            <div class="checkbox-group" onclick="toggleCheckbox()">
                <asp:CheckBox ID="chkHasChapters" runat="server" />
                <span class="checkbox-label">
                    该资源包含多个章节
                </span>
            </div>
            <div class="checkbox-hint">
                勾选后，创建资源后将跳转到章节管理页面
            </div>
        </div>
        
        <asp:Button ID="btnCreate" runat="server" CssClass="btn-create" OnClick="btnCreate_Click" Text="创建资源" />
    </div>
</div>

<div id="toast" class="toast">
    <span class="toast-icon" id="toastIcon"></span>
    <span class="toast-message" id="toastMessage"></span>
</div>

<script type="text/javascript">
    function showToast(message, type) {
        var toast = document.getElementById('toast');
        var icon = document.getElementById('toastIcon');
        var msg = document.getElementById('toastMessage');
        toast.className = 'toast ' + type;
        icon.textContent = type === 'success' ? '✅' : '❌';
        msg.textContent = message;
        toast.style.display = 'flex';
        setTimeout(function() { toast.style.display = 'none'; }, 3000);
    }
    
    function toggleCheckbox() {
        var checkbox = document.getElementById('<%= chkHasChapters.ClientID %>');
        if (checkbox) {
            checkbox.checked = !checkbox.checked;
        }
    }
    
    function handleResourceFileSelect(input) {
        if (input.files && input.files[0]) {
            var file = input.files[0];
            var fileName = file.name;
            var fileSize = formatFileSize(file.size);
            var fileType = getFileType(fileName);
            
            // 隐藏初始提示
            document.getElementById('resourceUploadTitle').style.display = 'none';
            document.getElementById('resourceUploadText').style.display = 'none';
            document.getElementById('resourceUploadHint').style.display = 'none';
            document.getElementById('resourceUploadIcon').style.display = 'none';
            
            // 显示文件信息
            var fileInfo = document.getElementById('resourceFileInfo');
            fileInfo.style.display = 'flex';
            document.getElementById('resourceFileName').textContent = fileName;
            document.getElementById('resourceFileSize').textContent = fileSize;
            document.getElementById('resourceFileType').textContent = fileType;
            
            // 改变上传框样式
            document.getElementById('resourceUploadBox').classList.add('has-file');
        }
    }
    
    function getFileType(fileName) {
        var ext = fileName.split('.').pop().toLowerCase();
        var types = {
            'mp4': '视频', 'avi': '视频', 'mkv': '视频', 'mov': '视频', 'wmv': '视频', 'flv': '视频',
            'mp3': '音频', 'wav': '音频', 'flac': '音频', 'aac': '音频', 'ogg': '音频',
            'pdf': '文档', 'doc': '文档', 'docx': '文档', 'xls': '文档', 'xlsx': '文档', 'ppt': '文档', 'pptx': '文档', 'txt': '文档',
            'jpg': '图片', 'jpeg': '图片', 'png': '图片', 'gif': '图片', 'bmp': '图片', 'svg': '图片',
            'zip': '压缩包', 'rar': '压缩包', '7z': '压缩包', 'tar': '压缩包', 'gz': '压缩包',
            'html': '代码', 'css': '代码', 'js': '代码', 'py': '代码', 'java': '代码', 'cpp': '代码', 'c': '代码'
        };
        return types[ext] || '文件';
    }
    
    function handleCoverFileSelect(input) {
        if (input.files && input.files[0]) {
            var file = input.files[0];
            var reader = new FileReader();
            
            reader.onload = function(e) {
                // 显示预览
                document.getElementById('coverPreview').style.display = 'block';
                document.getElementById('coverPreviewImg').src = e.target.result;
                document.getElementById('coverUploadText').style.display = 'none';
            };
            
            reader.readAsDataURL(file);
        }
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        var k = 1024;
        var sizes = ['Bytes', 'KB', 'MB', 'GB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
</script>
</asp:Content>
