<%@ Page Language="C#" MasterPageFile="~/teacher/Teach.master" AutoEventWireup="true" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>

<script runat="server">
    private string GetConnStr()
    {
        string cs = null;
        try
        {
            Type dbType = typeof(LearnSite.Common.CookieHelp).Assembly.GetType("LearnSite.DBUtility.DbHelperSQL");
            if (dbType != null)
            {
                System.Reflection.FieldInfo f = dbType.GetField("connectionString",
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                if (f != null) cs = f.GetValue(null) as string;
            }
        }
        catch { }
        if (string.IsNullOrEmpty(cs))
        { try { cs = System.Configuration.ConfigurationManager.ConnectionStrings["SqlServer"].ConnectionString; } catch { } }
        if (cs != null && cs.ToLower().IndexOf("connection timeout") < 0 && cs.ToLower().IndexOf("connect timeout") < 0)
            cs = cs.TrimEnd(';') + ";Connection Timeout=5;";
        return cs;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCategories();
        }
    }

    protected void BindCategories()
    {
        string connStr = GetConnStr();
        if (string.IsNullOrEmpty(connStr)) return;
        
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string sql = @"SELECT CategoryId, CategoryName, CategoryIcon, CategoryColor, Description, 
                          SortOrder, IsActive, CreateTime,
                          (SELECT COUNT(*) FROM Files WHERE CategoryId = ResourceCategories.CategoryId) as ResourceCount
                          FROM ResourceCategories 
                          ORDER BY SortOrder, CategoryId";
            SqlDataAdapter da = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            rptCategories.DataSource = dt;
            rptCategories.DataBind();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        string connStr = GetConnStr();
        if (string.IsNullOrEmpty(connStr)) return;
        
        string name = txtCategoryName.Text.Trim();
        if (string.IsNullOrEmpty(name))
        {
            ShowMessage("请输入分类名称", "error");
            return;
        }
        
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            string sql = @"INSERT INTO ResourceCategories (CategoryName, CategoryIcon, CategoryColor, Description, SortOrder, IsActive)
                          VALUES (@Name, @Icon, @Color, @Desc, @Sort, 1)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Name", name);
            cmd.Parameters.AddWithValue("@Icon", txtCategoryIcon.Text.Trim());
            cmd.Parameters.AddWithValue("@Color", txtCategoryColor.Text.Trim());
            cmd.Parameters.AddWithValue("@Desc", txtCategoryDesc.Text.Trim());
            cmd.Parameters.AddWithValue("@Sort", string.IsNullOrEmpty(txtSortOrder.Text) ? 0 : int.Parse(txtSortOrder.Text));
            cmd.ExecuteNonQuery();
        }
        
        txtCategoryName.Text = "";
        txtCategoryIcon.Text = "";
        txtCategoryColor.Text = "#3b82f6";
        txtCategoryDesc.Text = "";
        txtSortOrder.Text = "0";
        
        ShowMessage("分类添加成功！", "success");
        BindCategories();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        string categoryId = btn.CommandArgument;
        
        string connStr = GetConnStr();
        if (string.IsNullOrEmpty(connStr)) return;
        
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            
            string checkSql = "SELECT COUNT(*) FROM Files WHERE CategoryId = @CategoryId";
            SqlCommand checkCmd = new SqlCommand(checkSql, conn);
            checkCmd.Parameters.AddWithValue("@CategoryId", categoryId);
            int count = (int)checkCmd.ExecuteScalar();
            
            if (count > 0)
            {
                ShowMessage("该分类下还有资源，无法删除", "error");
                return;
            }
            
            string sql = "DELETE FROM ResourceCategories WHERE CategoryId = @CategoryId";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@CategoryId", categoryId);
            cmd.ExecuteNonQuery();
        }
        
        ShowMessage("删除成功！", "success");
        BindCategories();
    }

    protected string GetCategoryIcon(object categoryName)
    {
        string name = categoryName.ToString().ToLower();
        
        if (name.Contains("视频") || name.Contains("教程"))
            return "<svg viewBox='0 0 24 24'><path d='M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z'/></svg>";
        
        if (name.Contains("音频") || name.Contains("音乐"))
            return "<svg viewBox='0 0 24 24'><path d='M9 18V5l12-2v13M9 18c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3zm12-2c0 1.657-1.343 3-3 3s-3-1.343-3-3 1.343-3 3-3 3 1.343 3 3z'/></svg>";
        
        if (name.Contains("图片") || name.Contains("素材") || name.Contains("图像"))
            return "<svg viewBox='0 0 24 24'><rect x='3' y='3' width='18' height='18' rx='2' ry='2'/><circle cx='8.5' cy='8.5' r='1.5'/><polyline points='21 15 16 10 5 21'/></svg>";
        
        if (name.Contains("文档") || name.Contains("文件") || name.Contains("资料"))
            return "<svg viewBox='0 0 24 24'><path d='M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'/></svg>";
        
        if (name.Contains("代码") || name.Contains("编程") || name.Contains("源码"))
            return "<svg viewBox='0 0 24 24'><polyline points='16 18 22 12 16 6'/><polyline points='8 6 2 12 8 18'/></svg>";
        
        if (name.Contains("压缩") || name.Contains("打包"))
            return "<svg viewBox='0 0 24 24'><path d='M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z'/></svg>";
        
        if (name.Contains("课件") || name.Contains("ppt") || name.Contains("演示"))
            return "<svg viewBox='0 0 24 24'><path d='M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z'/><path d='M11 14l2 2 4-4'/></svg>";
        
        if (name.Contains("工具") || name.Contains("软件"))
            return "<svg viewBox='0 0 24 24'><path d='M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z'/></svg>";
        
        return "<svg viewBox='0 0 24 24'><path d='M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z'/></svg>";
    }

    private void ShowMessage(string message, string type)
    {
        string script = string.Format("showToast('{0}', '{1}');", message.Replace("'", "\\'"), type);
        ClientScript.RegisterStartupScript(this.GetType(), "toast", script, true);
    }

</script>

<asp:Content ID="Content1" ContentPlaceHolderID="Content" runat="server">
<style>
    * { box-sizing: border-box; }
    .category-container { max-width: 1600px; margin: 0 auto; }
    
    .page-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px; padding: 40px; margin-bottom: 32px;
        color: white; box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);
        position: relative; overflow: hidden;
    }
    .page-header::before {
        content: ''; position: absolute; top: -50%; right: -10%;
        width: 400px; height: 400px; border-radius: 50%;
        background: rgba(255,255,255,0.1);
    }
    .page-header h1 { 
        margin: 0 0 12px 0; font-size: 32px; font-weight: 700;
        position: relative; z-index: 1;
        display: flex; align-items: center; gap: 12px;
    }
    .page-header h1 svg {
        width: 32px; height: 32px; stroke: currentColor;
    }
    .page-header p { 
        margin: 0; opacity: 0.95; font-size: 15px;
        position: relative; z-index: 1;
    }
    
    .add-card {
        background: white; border-radius: 20px; padding: 32px;
        margin-bottom: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .add-card h2 {
        margin: 0 0 24px 0; font-size: 20px; font-weight: 700;
        color: #1e293b; display: flex; align-items: center; gap: 10px;
        padding-bottom: 16px; border-bottom: 2px solid #f1f5f9;
    }
    .add-card h2 svg {
        width: 24px; height: 24px; stroke: #667eea;
    }
    .form-grid { 
        display: grid; grid-template-columns: repeat(3, 1fr); 
        gap: 20px; margin-bottom: 24px; 
    }
    .form-group { display: flex; flex-direction: column; }
    .form-group label {
        display: block; margin-bottom: 10px; font-size: 14px;
        font-weight: 600; color: #475569;
        display: flex; align-items: center; gap: 8px;
    }
    .form-group label svg {
        width: 16px; height: 16px; stroke: #94a3b8;
    }
    .form-control {
        padding: 12px 16px; border: 2px solid #e2e8f0;
        border-radius: 12px; font-size: 14px; transition: all 0.3s;
        background: #f8fafc; font-family: inherit;
    }
    .form-control:focus {
        outline: none; border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        background: white;
    }
    .form-control-desc {
        grid-column: 1 / 3;
    }
    .btn-save {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; border: none; padding: 14px 32px;
        border-radius: 12px; font-size: 15px; font-weight: 700;
        cursor: pointer; transition: all 0.3s;
        box-shadow: 0 4px 16px rgba(102, 126, 234, 0.4);
    }
    .btn-save:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 24px rgba(102, 126, 234, 0.5);
    }
    
    .categories-card {
        background: white; border-radius: 20px; padding: 32px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .categories-card h2 {
        margin: 0 0 24px 0; font-size: 20px; font-weight: 700;
        color: #1e293b; display: flex; align-items: center; gap: 10px;
        padding-bottom: 16px; border-bottom: 2px solid #f1f5f9;
    }
    .categories-card h2 svg {
        width: 24px; height: 24px; stroke: #667eea;
    }
    .categories-grid {
        display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 24px; margin-top: 24px;
    }
    .category-item {
        background: white; border: 2px solid #e2e8f0;
        border-radius: 16px; padding: 24px; transition: all 0.3s;
        position: relative; overflow: hidden;
    }
    .category-item::before {
        content: ''; position: absolute; top: 0; right: 0;
        width: 100px; height: 100px; border-radius: 50%;
        opacity: 0.08; transition: all 0.4s;
    }
    .category-item:hover {
        border-color: #667eea; 
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.15);
        transform: translateY(-4px);
    }
    .category-item:hover::before {
        transform: scale(1.3);
        opacity: 0.12;
    }
    .category-item:hover .btn-close-category {
        opacity: 1;
        transform: translate(0, 0);
    }
    
    .btn-close-category {
        position: absolute; top: 12px; right: 12px;
        width: 32px; height: 32px; border-radius: 8px;
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        border: 2px solid #fca5a5; cursor: pointer;
        transition: all 0.3s; z-index: 10;
        opacity: 0; transform: translate(8px, -8px);
        display: flex; align-items: center; justify-content: center;
        padding: 0; font-size: 0;
    }
    .btn-close-category::before {
        content: ''; position: absolute;
        width: 16px; height: 16px;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23dc2626' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cline x1='18' y1='6' x2='6' y2='18'%3E%3C/line%3E%3Cline x1='6' y1='6' x2='18' y2='18'%3E%3C/line%3E%3C/svg%3E");
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        transition: all 0.3s;
    }
    .btn-close-category:hover {
        background: linear-gradient(135deg, #fecaca 0%, #fca5a5 100%);
        transform: rotate(90deg) scale(1.1);
        box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
    }
    .btn-close-category:hover::before {
        transform: scale(1.15);
    }
    .category-header {
        display: flex; align-items: center; gap: 16px; 
        margin-bottom: 16px; position: relative; z-index: 1;
    }
    .category-icon {
        width: 64px; height: 64px; border-radius: 16px;
        display: flex; align-items: center; justify-content: center;
        font-size: 36px; flex-shrink: 0; font-weight: 700;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        transition: all 0.3s; position: relative;
        overflow: hidden;
    }
    .category-icon::before {
        content: ''; position: absolute; inset: -2px;
        border-radius: 18px; opacity: 0;
        background: inherit; filter: blur(8px);
        transition: all 0.3s; z-index: -1;
    }
    .category-item:hover .category-icon {
        transform: scale(1.1) rotate(-5deg);
        box-shadow: 0 8px 24px rgba(0,0,0,0.15);
    }
    .category-item:hover .category-icon::before {
        opacity: 0.4;
    }
    .category-icon svg {
        width: 36px; height: 36px;
        stroke: currentColor; fill: none;
        stroke-width: 2; stroke-linecap: round;
        stroke-linejoin: round;
    }
    .category-info { flex: 1; min-width: 0; }
    .category-name {
        font-size: 18px; font-weight: 700; color: #1e293b;
        margin-bottom: 6px;
    }
    .category-count {
        font-size: 14px; color: #64748b; font-weight: 500;
        display: flex; align-items: center; gap: 6px;
    }
    .category-count svg {
        width: 16px; height: 16px; stroke: currentColor;
    }
    .category-desc {
        font-size: 14px; color: #64748b; 
        line-height: 1.6; margin-bottom: 16px;
        position: relative; z-index: 1;
        min-height: 40px;
    }
    .category-actions {
        display: flex; gap: 10px; position: relative; z-index: 1;
    }
    .btn-action {
        flex: 1; padding: 10px 18px; border-radius: 10px;
        font-size: 14px; font-weight: 600; cursor: pointer;
        transition: all 0.3s; border: none;
        position: relative; overflow: hidden;
    }
    .btn-action::before {
        content: ''; position: absolute;
        top: 50%; left: 12px;
        width: 18px; height: 18px;
        transform: translateY(-50%);
        transition: all 0.3s;
    }
    .btn-delete {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        color: #dc2626; border: 2px solid #fca5a5;
        padding-left: 38px;
    }
    .btn-delete::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23dc2626' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='3 6 5 6 21 6'%3E%3C/polyline%3E%3Cpath d='M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'%3E%3C/path%3E%3Cline x1='10' y1='11' x2='10' y2='17'%3E%3C/line%3E%3Cline x1='14' y1='11' x2='14' y2='17'%3E%3C/line%3E%3C/svg%3E");
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
    }
    .btn-delete:hover { 
        background: linear-gradient(135deg, #fecaca 0%, #fca5a5 100%);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
    }
    .btn-delete:hover::before {
        transform: translateY(-50%) scale(1.1) rotate(-5deg);
    }
    
    .category-actions {
        display: flex; gap: 10px; position: relative; z-index: 1;
    }
    .btn-action {
        flex: 1; padding: 10px 18px; border-radius: 10px;
        font-size: 14px; font-weight: 600; cursor: pointer;
        transition: all 0.3s; border: none;
        position: relative; overflow: hidden;
    }
    .btn-action::before {
        content: ''; position: absolute;
        top: 50%; left: 12px;
        width: 18px; height: 18px;
        transform: translateY(-50%);
        transition: all 0.3s;
    }
    .btn-delete {
        background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
        color: #dc2626; border: 2px solid #fca5a5;
        padding-left: 38px;
    }
    .btn-delete::before {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23dc2626' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='3 6 5 6 21 6'%3E%3C/polyline%3E%3Cpath d='M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'%3E%3C/path%3E%3Cline x1='10' y1='11' x2='10' y2='17'%3E%3C/line%3E%3Cline x1='14' y1='11' x2='14' y2='17'%3E%3C/line%3E%3C/svg%3E");
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
    }
    .btn-delete:hover { 
        background: linear-gradient(135deg, #fecaca 0%, #fca5a5 100%);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
    }
    .btn-delete:hover::before {
        transform: translateY(-50%) scale(1.1) rotate(-5deg);
    }
    
    .empty-state {
        text-align: center; padding: 60px 20px;
        color: #94a3b8;
    }
    .empty-state-icon {
        font-size: 64px; margin-bottom: 16px;
        opacity: 0.5;
    }
    .empty-state-text {
        font-size: 16px; font-weight: 600;
    }
    
    .toast {
        position: fixed; top: 24px; right: 24px; background: white;
        padding: 18px 28px; border-radius: 16px;
        box-shadow: 0 12px 48px rgba(0,0,0,0.2); z-index: 10000;
        display: none; align-items: center; gap: 14px;
        animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        border-left: 4px solid;
    }
    @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    .toast.success { border-left-color: #10b981; }
    .toast.error { border-left-color: #ef4444; }
    .toast-icon { font-size: 24px; }
    .toast-message { font-size: 15px; font-weight: 500; color: #1e293b; }
</style>

<div class="category-container">
    <div class="page-header">
        <h1>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/>
            </svg>
            资源分类管理
        </h1>
        <p>管理资源分类，组织和归类教学资源</p>
    </div>
    
    <div class="add-card">
        <h2>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 4v16m8-8H4"/>
            </svg>
            添加分类
        </h2>
        <div class="form-grid">
            <div class="form-group">
                <label>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"/>
                    </svg>
                    分类名称
                </label>
                <asp:TextBox ID="txtCategoryName" runat="server" CssClass="form-control" placeholder="例如：视频教程"></asp:TextBox>
            </div>
            <div class="form-group">
                <label>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    分类图标
                </label>
                <asp:TextBox ID="txtCategoryIcon" runat="server" CssClass="form-control" placeholder="例如：🎬"></asp:TextBox>
            </div>
            <div class="form-group">
                <label>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/>
                    </svg>
                    分类颜色
                </label>
                <asp:TextBox ID="txtCategoryColor" runat="server" CssClass="form-control" Text="#3b82f6" placeholder="#3b82f6"></asp:TextBox>
            </div>
        </div>
        <div class="form-grid">
            <div class="form-group form-control-desc">
                <label>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 6h16M4 12h16M4 18h7"/>
                    </svg>
                    分类描述
                </label>
                <asp:TextBox ID="txtCategoryDesc" runat="server" CssClass="form-control" placeholder="描述该分类的用途"></asp:TextBox>
            </div>
            <div class="form-group">
                <label>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                    </svg>
                    排序
                </label>
                <asp:TextBox ID="txtSortOrder" runat="server" CssClass="form-control" Text="0" placeholder="数字越小越靠前"></asp:TextBox>
            </div>
        </div>
        <asp:Button ID="btnSave" runat="server" Text="➕ 添加分类" CssClass="btn-save" OnClick="btnSave_Click" />
    </div>
    
    <div class="categories-card">
        <h2>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M4 6h16M4 10h16M4 14h16M4 18h16"/>
            </svg>
            分类列表
        </h2>
        <div class="categories-grid">
            <asp:Repeater ID="rptCategories" runat="server">
                <ItemTemplate>
                    <div class="category-item" style='<%# "border-color: " + Eval("CategoryColor") + "40;" %>'>
                        <asp:Button ID="btnDelete" runat="server" CssClass="btn-close-category"
                                    CommandArgument='<%# Eval("CategoryId") %>' OnClick="btnDelete_Click"
                                    OnClientClick="return confirm('确定要删除这个分类吗？\n\n分类名称：' + this.getAttribute('data-name') + '\n资源数量：' + this.getAttribute('data-count') + ' 个');"
                                    data-name='<%# Eval("CategoryName") %>' data-count='<%# Eval("ResourceCount") %>' />
                        <div class="category-header">
                            <div class="category-icon" style='background: linear-gradient(135deg, <%# Eval("CategoryColor") %>15 0%, <%# Eval("CategoryColor") %>35 100%); color: <%# Eval("CategoryColor") %>; border: 3px solid <%# Eval("CategoryColor") %>25;'>
                                <%# GetCategoryIcon(Eval("CategoryName")) %>
                            </div>
                            <div class="category-info">
                                <div class="category-name"><%# Eval("CategoryName") %></div>
                                <div class="category-count">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                    <%# Eval("ResourceCount") %> 个资源
                                </div>
                            </div>
                        </div>
                        <div class="category-desc"><%# string.IsNullOrEmpty(Eval("Description").ToString()) ? "暂无描述" : Eval("Description") %></div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>
</div>

<div id="toast" class="toast">
    <span class="toast-icon" id="toastIcon"></span>
    <span class="toast-message" id="toastMessage"></span>
</div>

<script type="text/javascript">
    function showToast(message, type) {
        var toast = document.getElementById('toast');
        var icon = document.getElementById('toastIcon');
        var msg = document.getElementById('toastMessage');
        toast.className = 'toast ' + type;
        icon.textContent = type === 'success' ? '✅' : '❌';
        msg.textContent = message;
        toast.style.display = 'flex';
        setTimeout(function() { toast.style.display = 'none'; }, 3000);
    }
</script>
</asp:Content>
