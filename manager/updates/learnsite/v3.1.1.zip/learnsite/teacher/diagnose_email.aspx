<%@ Page Language="C#" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Configuration" %>

<!DOCTYPE html>
<html>
<head>
    <title>邮箱字段诊断</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .info { background: #e3f2fd; padding: 10px; margin: 10px 0; border-radius: 5px; }
        .error { background: #ffebee; padding: 10px; margin: 10px 0; border-radius: 5px; }
        .success { background: #e8f5e9; padding: 10px; margin: 10px 0; border-radius: 5px; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>教师邮箱字段诊断</h1>
    
<%
    // 获取当前登录的教师ID
    int teacherId = 0;
    HttpCookie tc = Request.Cookies[LearnSite.Common.CookieHelp.teaCookieNname];
    if (tc != null && !string.IsNullOrEmpty(tc.Value))
    {
        try
        {
            Type cookType = typeof(LearnSite.Common.CookieHelp).Assembly.GetType("LearnSite.Model.TeaCook");
            if (cookType != null)
            {
                object model = Activator.CreateInstance(cookType);
                System.Reflection.MethodInfo toModel = cookType.GetMethod("ToModel", 
                    System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | 
                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Static);
                if (toModel != null)
                {
                    toModel.Invoke(model, new object[] { tc.Value });
                    System.Reflection.PropertyInfo hidProp = cookType.GetProperty("Hid");
                    if (hidProp != null)
                    {
                        object v = hidProp.GetValue(model, null);
                        if (v != null) int.TryParse(v.ToString(), out teacherId);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("<div class='error'>获取教师ID失败: " + Server.HtmlEncode(ex.Message) + "</div>");
        }
    }
    
    if (teacherId <= 0)
    {
        Response.Write("<div class='error'>未登录或无法获取教师ID</div>");
        return;
    }
    
    Response.Write("<div class='info'>当前教师ID: " + teacherId + "</div>");
    
    string connStr = ConfigurationManager.ConnectionStrings["SqlServer"].ConnectionString;
    string[] tables = { "Teacher", "Teachers" };
    
    foreach (string table in tables)
    {
        Response.Write("<h2>表: " + table + "</h2>");
        
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            try
            {
                conn.Open();
                
                // 检查表是否存在
                string checkTableSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = @TableName";
                SqlCommand checkCmd = new SqlCommand(checkTableSql, conn);
                checkCmd.Parameters.AddWithValue("@TableName", table);
                int tableExists = (int)checkCmd.ExecuteScalar();
                
                if (tableExists == 0)
                {
                    Response.Write("<div class='error'>表不存在</div>");
                    continue;
                }
                
                Response.Write("<div class='success'>表存在</div>");
                
                // 获取所有列名
                string columnsSql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName";
                SqlCommand colCmd = new SqlCommand(columnsSql, conn);
                colCmd.Parameters.AddWithValue("@TableName", table);
                
                Response.Write("<h3>表结构:</h3><pre>");
                using (SqlDataReader reader = colCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string colName = reader["COLUMN_NAME"].ToString();
                        string dataType = reader["DATA_TYPE"].ToString();
                        Response.Write(colName + " (" + dataType + ")\n");
                    }
                }
                Response.Write("</pre>");
                
                // 查询当前教师记录
                string selectSql = "SELECT * FROM " + table + " WHERE Hid=@Hid";
                SqlCommand selectCmd = new SqlCommand(selectSql, conn);
                selectCmd.Parameters.AddWithValue("@Hid", teacherId);
                
                Response.Write("<h3>当前教师记录:</h3><pre>");
                using (SqlDataReader reader = selectCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            string fieldName = reader.GetName(i);
                            object fieldValue = reader[i];
                            string valueStr = fieldValue == DBNull.Value ? "(NULL)" : fieldValue.ToString();
                            Response.Write(fieldName + " = " + Server.HtmlEncode(valueStr) + "\n");
                        }
                    }
                    else
                    {
                        Response.Write("未找到记录");
                    }
                }
                Response.Write("</pre>");
            }
            catch (Exception ex)
            {
                Response.Write("<div class='error'>错误: " + Server.HtmlEncode(ex.Message) + "</div>");
            }
        }
    }
%>

    <hr/>
    <p><a href="profile.aspx">返回个人中心</a></p>
</body>
</html>
